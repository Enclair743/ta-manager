# TA Manager — Next.js Starter

Aplikasi manajemen Tugas Akhir (dashboard, penulisan, catatan, referensi, calendar) — Starter project.

## Cara pakai (tanpa terminal)
1. Buat repository baru di GitHub.
2. Upload semua file/folder dari proyek ini via GitHub Web (Add file → Upload files).
3. Buka https://vercel.com → Login with GitHub → New Project → import repository.
4. Deploy → selesai. Setiap kali kamu edit file di GitHub → Vercel akan auto-deploy.

## Fitur
- Dashboard: ringkasan progress & countdown.
- Penulisan: editor Markdown + preview + export MD.
- Catatan: simpan catatan bimbingan di browser.
- Referensi: tambah referensi, format APA sederhana, export.
- Calendar: kalender lokal + events (localStorage).

## Pengembangan lanjut
- Simpan data ke DB (Supabase / Firebase / Postgres).
- Integrasi Google Calendar (NextAuth + Google API).
- Tambah autentikasi pengguna.
- Perbaiki generator sitasi (import .bib atau integrasi Zotero).

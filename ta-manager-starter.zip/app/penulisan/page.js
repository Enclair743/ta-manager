'use client';
import { useEffect, useState } from 'react';
import ReactMarkdown from 'react-markdown';

export default function PenulisanPage(){
  const storageKey = 'ta_draft_bab1';
  const [text, setText] = useState('');

  useEffect(()=> {
    const saved = localStorage.getItem(storageKey) || `# Bab I — Pendahuluan\n\nTulis draftmu di sini...`;
    setText(saved);
  },[]);

  function saveDraft(){
    localStorage.setItem(storageKey, text);
    alert('Draft tersimpan di localStorage.');
  }

  function exportTxt(){
    const blob = new Blob([text], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'Bab_I_draft.md';
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Penulisan — Editor</h2>
      <div className="flex gap-4 flex-col md:flex-row">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <button className="px-3 py-1 bg-blue-600 text-white rounded" onClick={saveDraft}>Simpan</button>
            <button className="px-3 py-1 bg-slate-100 rounded" onClick={exportTxt}>Export MD</button>
            <div className="text-sm text-slate-500 ml-auto">Autosave via tombol; data disimpan di browser</div>
          </div>
          <textarea value={text} onChange={e=>setText(e.target.value)}
            className="w-full h-[60vh] p-3 border rounded resize-none" />
        </div>

        <div className="flex-1">
          <h3 className="font-medium mb-2">Preview</h3>
          <div className="prose bg-white p-4 border rounded h-[60vh] overflow-auto">
            <ReactMarkdown>{text}</ReactMarkdown>
          </div>
        </div>
      </div>
    </div>
  );
}

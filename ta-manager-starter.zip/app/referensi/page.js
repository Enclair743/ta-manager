'use client';
import { useEffect, useState } from 'react';

function toAPA(item){
  const authors = item.authors || 'Anonim';
  const year = item.year || 'n.d.';
  const title = item.title || '';
  const source = item.source || '';
  return `${authors} (${year}). ${title}. ${source}`;
}

export default function ReferensiPage(){
  const key = 'ta_refs';
  const [refs, setRefs] = useState([]);
  const [form, setForm] = useState({ authors:'', year:'', title:'', source:'' });

  useEffect(()=> {
    const raw = localStorage.getItem(key) || '[]';
    setRefs(JSON.parse(raw));
  },[]);

  function addRef(){
    if(!form.title.trim()) return alert('Isi judul referensi.');
    const next = [ {...form, id: Date.now()}, ...refs ];
    setRefs(next); localStorage.setItem(key, JSON.stringify(next));
    setForm({ authors:'', year:'', title:'', source:'' });
  }

  function remove(id){
    if(!confirm('Hapus referensi?')) return;
    const next = refs.filter(r=>r.id!==id);
    setRefs(next); localStorage.setItem(key, JSON.stringify(next));
  }

  function exportBib(){
    const lines = refs.map((r,i)=>`@ref${i+1}{\n  author = {${r.authors}},\n  year = {${r.year}},\n  title = {${r.title}},\n  source = {${r.source}}\n}`);
    const blob = new Blob([lines.join('\n\n')], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'references.txt'; a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Referensi & Daftar Pustaka</h2>

      <div className="bg-white p-4 rounded shadow-sm">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          <input placeholder="Penulis (format: Nama, A.)" value={form.authors} onChange={e=>setForm({...form,authors:e.target.value})} className="p-2 border rounded" />
          <input placeholder="Tahun (yyyy)" value={form.year} onChange={e=>setForm({...form,year:e.target.value})} className="p-2 border rounded" />
          <input placeholder="Judul" value={form.title} onChange={e=>setForm({...form,title:e.target.value})} className="p-2 border rounded md:col-span-2" />
          <input placeholder="Sumber / Jurnal / URL" value={form.source} onChange={e=>setForm({...form,source:e.target.value})} className="p-2 border rounded md:col-span-2" />
        </div>

        <div className="mt-2 flex gap-2">
          <button onClick={addRef} className="px-3 py-2 bg-green-600 text-white rounded">Tambah Referensi</button>
          <button onClick={exportBib} className="px-3 py-2 bg-slate-100 rounded">Export List</button>
        </div>
      </div>

      <div className="mt-4">
        <h3 className="font-medium mb-2">Daftar Pustaka (APA sederhana)</h3>
        <div className="space-y-2">
          {refs.length === 0 && <div className="text-slate-500">Belum ada referensi.</div>}
          {refs.map(r=>(
            <div key={r.id} className="bg-white p-3 rounded shadow-sm flex justify-between items-start">
              <div>{toAPA(r)}</div>
              <div className="text-sm">
                <button onClick={()=>remove(r.id)} className="text-red-500">Hapus</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

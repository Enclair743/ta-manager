import './globals.css';
import Navbar from '../components/Navbar';

export const metadata = {
  title: 'TA Manager',
  description: 'Aplikasi manajemen Tugas Akhir (dashboard, penulisan, catatan, referensi, kalender)'
};

export default function RootLayout({ children }) {
  return (
    <html lang="id">
      <body>
        <Navbar />
        <main className="max-w-5xl mx-auto p-6">
          {children}
        </main>
      </body>
    </html>
  );
}

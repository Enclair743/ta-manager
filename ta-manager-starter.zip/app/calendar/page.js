'use client';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import { useState, useEffect } from 'react';

export default function CalendarPage(){
  const [date, setDate] = useState(new Date());
  const key = 'ta_events';
  const [events, setEvents] = useState([]);
  const [title, setTitle] = useState('');

  useEffect(()=> {
    const raw = localStorage.getItem(key) || '[]';
    setEvents(JSON.parse(raw));
  },[]);

  function addEvent(){
    if(!title.trim()) return alert('Masukkan judul event.');
    const ev = { id: Date.now(), date: date.toISOString().split('T')[0], title };
    const next = [ev, ...events];
    setEvents(next); localStorage.setItem(key, JSON.stringify(next));
    setTitle('');
  }

  function remove(id){
    if(!confirm('Hapus event?')) return;
    const next = events.filter(e=>e.id !== id);
    setEvents(next); localStorage.setItem(key, JSON.stringify(next));
  }

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Calendar & Timeline</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white p-4 rounded shadow-sm">
          <Calendar onChange={setDate} value={date} />
          <div className="mt-2">
            <div className="text-sm text-slate-600">Dipilih: {date.toDateString()}</div>
            <div className="mt-2 flex gap-2">
              <input placeholder="Judul event" value={title} onChange={e=>setTitle(e.target.value)} className="p-2 border rounded flex-1" />
              <button onClick={addEvent} className="px-3 py-2 bg-blue-600 text-white rounded">Tambah</button>
            </div>
          </div>
        </div>

        <div className="bg-white p-4 rounded shadow-sm">
          <h3 className="font-medium">Events / Timeline</h3>
          <div className="mt-3 space-y-2">
            {events.length === 0 && <div className="text-slate-500">Belum ada event.</div>}
            {events.map(ev=>(
              <div key={ev.id} className="p-3 bg-slate-50 rounded flex justify-between items-center">
                <div>
                  <div className="text-sm text-slate-500">{ev.date}</div>
                  <div className="font-medium">{ev.title}</div>
                </div>
                <div>
                  <button onClick={()=>remove(ev.id)} className="text-red-500 text-sm">Hapus</button>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-4 text-sm text-slate-600">
            <div>Catatan: untuk sinkron Google Calendar, kita perlu integrasi OAuth (NextAuth) dan Google API. Mau lanjut integrasi ini nanti?</div>
          </div>
        </div>
      </div>
    </div>
  );
}

import ProgressBar from '../components/ProgressBar';

export default function DashboardPage(){
  const progress = { BabI: 100, BabII: 40, BabIII: 0, BabIV: 0, BabV: 0 };
  const keys = Object.keys(progress);
  const avg = Math.round(keys.reduce((s,k)=>s+progress[k],0) / keys.length);

  const deadline = new Date(Date.now() + 60*24*60*60*1000);
  const daysLeft = Math.ceil((deadline - new Date()) / (1000*60*60*24));

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Dashboard</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white p-4 rounded shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-medium">Progress Rata-Rata</h3>
              <div className="text-3xl font-bold mt-2">{avg}%</div>
            </div>
            <div className="text-sm text-slate-500 text-right">
              <div>Target Sidang</div>
              <div className="font-semibold">{deadline.toDateString()}</div>
              <div className="mt-2">{daysLeft} hari lagi</div>
            </div>
          </div>

          <div className="mt-4">
            <ProgressBar percent={avg} />
          </div>

          <div className="mt-4">
            <h4 className="font-medium">Detail Bab</h4>
            <ul className="list-disc ml-6 mt-2">
              {keys.map(k=>(
                <li key={k}>{k}: {progress[k]}%</li>
              ))}
            </ul>
          </div>
        </div>

        <div className="bg-white p-4 rounded shadow-sm">
          <h3 className="font-medium">Ringkasan Terbaru</h3>
          <div className="mt-3 text-sm text-slate-600">Catatan bimbingan dan tugas revisi terbaru akan muncul di sini.</div>
          <div className="mt-3">
            <div className="bg-slate-50 p-3 rounded">Belum ada data dinamis — gunakan halaman Catatan & Referensi untuk input.</div>
          </div>
        </div>
      </div>
    </div>
  );
}

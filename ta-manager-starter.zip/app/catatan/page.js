'use client';
import { useEffect, useState } from 'react';

export default function CatatanPage(){
  const key = 'ta_notes';
  const [notes, setNotes] = useState([]);
  const [text, setText] = useState('');
  const [dosen, setDosen] = useState('');
  const [topic, setTopic] = useState('');

  useEffect(()=> {
    const raw = localStorage.getItem(key) || '[]';
    setNotes(JSON.parse(raw));
  },[]);

  function saveNote(){
    if(!text.trim()) return alert('Isi catatan terlebih dahulu.');
    const n = { id: Date.now(), date: new Date().toISOString().split('T')[0], dosen, topic, text };
    const next = [n, ...notes];
    setNotes(next);
    localStorage.setItem(key, JSON.stringify(next));
    setText(''); setTopic(''); setDosen('');
  }

  function remove(id){
    if(!confirm('Hapus catatan ini?')) return;
    const next = notes.filter(n=>n.id !== id);
    setNotes(next); localStorage.setItem(key, JSON.stringify(next));
  }

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Catatan Bimbingan</h2>

      <div className="bg-white p-4 rounded shadow-sm">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mb-2">
          <input placeholder="Dosen" value={dosen} onChange={e=>setDosen(e.target.value)} className="p-2 border rounded" />
          <input placeholder="Topik / Bab" value={topic} onChange={e=>setTopic(e.target.value)} className="p-2 border rounded" />
          <div className="flex gap-2">
            <button onClick={saveNote} className="px-3 py-2 bg-blue-600 text-white rounded">Simpan Catatan</button>
            <button onClick={()=>{setText(''); setTopic(''); setDosen('')}} className="px-3 py-2 bg-slate-100 rounded">Bersihkan</button>
          </div>
        </div>
        <textarea placeholder="Ringkasan bimbingan..." value={text} onChange={e=>setText(e.target.value)} className="w-full p-2 border rounded h-28" />
      </div>

      <div className="mt-4 space-y-3">
        {notes.length === 0 && <div className="text-slate-500">Belum ada catatan.</div>}
        {notes.map(n=>(
          <div key={n.id} className="bg-white p-3 rounded shadow-sm">
            <div className="flex items-start justify-between">
              <div>
                <div className="text-sm text-slate-500">{n.date} • {n.dosen || '–'} • {n.topic || '–'}</div>
                <div className="mt-2">{n.text}</div>
              </div>
              <div className="text-right">
                <button onClick={()=>remove(n.id)} className="text-sm text-red-500">Hapus</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function ProgressBar({percent = 0}) {
  return (
    <div className="w-full bg-slate-200 rounded h-4">
      <div style={{width: `${percent}%`}} className="bg-emerald-500 h-4 rounded"></div>
    </div>
  );
}

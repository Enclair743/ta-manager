'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

export default function Navbar(){
  const path = usePathname() || '/';
  const linkClass = (p) => `px-3 py-1 rounded ${path === p ? 'bg-slate-100 font-semibold' : 'hover:bg-slate-50'}`;

  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-5xl mx-auto p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-pink-500 rounded flex items-center justify-center text-white font-bold">TA</div>
          <div>
            <h1 className="text-lg font-bold">TA Manager</h1>
            <div className="text-sm text-slate-500">Manajemen Tugas Akhir — simpel & rapi</div>
          </div>
        </div>

        <nav className="flex items-center gap-2 text-sm">
          <Link className={linkClass('/')} href="/">Dashboard</Link>
          <Link className={linkClass('/penulisan')} href="/penulisan">Penulisan</Link>
          <Link className={linkClass('/catatan')} href="/catatan">Catatan</Link>
          <Link className={linkClass('/referensi')} href="/referensi">Referensi</Link>
          <Link className={linkClass('/calendar')} href="/calendar">Calendar</Link>
        </nav>
      </div>
    </header>
  );
}
